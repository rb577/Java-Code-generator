package project.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import project.services.MydslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMydslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_INT", "RULE_I_HAVE", "RULE_DRANK", "RULE_DRINKING", "RULE_GIVEN_TEXT", "RULE_AND_TEXT", "RULE_COKES", "RULE_ID", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER"
    };
    public static final int RULE_ID=11;
    public static final int RULE_I_HAVE=5;
    public static final int RULE_WS=15;
    public static final int RULE_DRANK=6;
    public static final int RULE_STRING=12;
    public static final int RULE_ANY_OTHER=16;
    public static final int RULE_SL_COMMENT=14;
    public static final int RULE_GIVEN_TEXT=8;
    public static final int RULE_DRINKING=7;
    public static final int RULE_INT=4;
    public static final int RULE_ML_COMMENT=13;
    public static final int EOF=-1;
    public static final int RULE_COKES=10;
    public static final int RULE_AND_TEXT=9;

    // delegates
    // delegators


        public InternalMydslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMydslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMydslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMydsl.g"; }


    	private MydslGrammarAccess grammarAccess;

    	public void setGrammarAccess(MydslGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRulemodel"
    // InternalMydsl.g:53:1: entryRulemodel : rulemodel EOF ;
    public final void entryRulemodel() throws RecognitionException {
        try {
            // InternalMydsl.g:54:1: ( rulemodel EOF )
            // InternalMydsl.g:55:1: rulemodel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            rulemodel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulemodel"


    // $ANTLR start "rulemodel"
    // InternalMydsl.g:62:1: rulemodel : ( ( rule__Model__Group__0 ) ) ;
    public final void rulemodel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:66:2: ( ( ( rule__Model__Group__0 ) ) )
            // InternalMydsl.g:67:2: ( ( rule__Model__Group__0 ) )
            {
            // InternalMydsl.g:67:2: ( ( rule__Model__Group__0 ) )
            // InternalMydsl.g:68:3: ( rule__Model__Group__0 )
            {
             before(grammarAccess.getModelAccess().getGroup()); 
            // InternalMydsl.g:69:3: ( rule__Model__Group__0 )
            // InternalMydsl.g:69:4: rule__Model__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Model__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulemodel"


    // $ANTLR start "entryRuleElement"
    // InternalMydsl.g:78:1: entryRuleElement : ruleElement EOF ;
    public final void entryRuleElement() throws RecognitionException {
        try {
            // InternalMydsl.g:79:1: ( ruleElement EOF )
            // InternalMydsl.g:80:1: ruleElement EOF
            {
             before(grammarAccess.getElementRule()); 
            pushFollow(FOLLOW_1);
            ruleElement();

            state._fsp--;

             after(grammarAccess.getElementRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleElement"


    // $ANTLR start "ruleElement"
    // InternalMydsl.g:87:1: ruleElement : ( ( rule__Element__Alternatives ) ) ;
    public final void ruleElement() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:91:2: ( ( ( rule__Element__Alternatives ) ) )
            // InternalMydsl.g:92:2: ( ( rule__Element__Alternatives ) )
            {
            // InternalMydsl.g:92:2: ( ( rule__Element__Alternatives ) )
            // InternalMydsl.g:93:3: ( rule__Element__Alternatives )
            {
             before(grammarAccess.getElementAccess().getAlternatives()); 
            // InternalMydsl.g:94:3: ( rule__Element__Alternatives )
            // InternalMydsl.g:94:4: rule__Element__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Element__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getElementAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleElement"


    // $ANTLR start "entryRuleIhave"
    // InternalMydsl.g:103:1: entryRuleIhave : ruleIhave EOF ;
    public final void entryRuleIhave() throws RecognitionException {
        try {
            // InternalMydsl.g:104:1: ( ruleIhave EOF )
            // InternalMydsl.g:105:1: ruleIhave EOF
            {
             before(grammarAccess.getIhaveRule()); 
            pushFollow(FOLLOW_1);
            ruleIhave();

            state._fsp--;

             after(grammarAccess.getIhaveRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleIhave"


    // $ANTLR start "ruleIhave"
    // InternalMydsl.g:112:1: ruleIhave : ( ( rule__Ihave__NameAssignment ) ) ;
    public final void ruleIhave() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:116:2: ( ( ( rule__Ihave__NameAssignment ) ) )
            // InternalMydsl.g:117:2: ( ( rule__Ihave__NameAssignment ) )
            {
            // InternalMydsl.g:117:2: ( ( rule__Ihave__NameAssignment ) )
            // InternalMydsl.g:118:3: ( rule__Ihave__NameAssignment )
            {
             before(grammarAccess.getIhaveAccess().getNameAssignment()); 
            // InternalMydsl.g:119:3: ( rule__Ihave__NameAssignment )
            // InternalMydsl.g:119:4: rule__Ihave__NameAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Ihave__NameAssignment();

            state._fsp--;


            }

             after(grammarAccess.getIhaveAccess().getNameAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleIhave"


    // $ANTLR start "entryRuleIdr"
    // InternalMydsl.g:128:1: entryRuleIdr : ruleIdr EOF ;
    public final void entryRuleIdr() throws RecognitionException {
        try {
            // InternalMydsl.g:129:1: ( ruleIdr EOF )
            // InternalMydsl.g:130:1: ruleIdr EOF
            {
             before(grammarAccess.getIdrRule()); 
            pushFollow(FOLLOW_1);
            ruleIdr();

            state._fsp--;

             after(grammarAccess.getIdrRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleIdr"


    // $ANTLR start "ruleIdr"
    // InternalMydsl.g:137:1: ruleIdr : ( ( rule__Idr__NameAssignment ) ) ;
    public final void ruleIdr() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:141:2: ( ( ( rule__Idr__NameAssignment ) ) )
            // InternalMydsl.g:142:2: ( ( rule__Idr__NameAssignment ) )
            {
            // InternalMydsl.g:142:2: ( ( rule__Idr__NameAssignment ) )
            // InternalMydsl.g:143:3: ( rule__Idr__NameAssignment )
            {
             before(grammarAccess.getIdrAccess().getNameAssignment()); 
            // InternalMydsl.g:144:3: ( rule__Idr__NameAssignment )
            // InternalMydsl.g:144:4: rule__Idr__NameAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Idr__NameAssignment();

            state._fsp--;


            }

             after(grammarAccess.getIdrAccess().getNameAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleIdr"


    // $ANTLR start "entryRuleScenario"
    // InternalMydsl.g:153:1: entryRuleScenario : ruleScenario EOF ;
    public final void entryRuleScenario() throws RecognitionException {
        try {
            // InternalMydsl.g:154:1: ( ruleScenario EOF )
            // InternalMydsl.g:155:1: ruleScenario EOF
            {
             before(grammarAccess.getScenarioRule()); 
            pushFollow(FOLLOW_1);
            ruleScenario();

            state._fsp--;

             after(grammarAccess.getScenarioRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleScenario"


    // $ANTLR start "ruleScenario"
    // InternalMydsl.g:162:1: ruleScenario : ( ( rule__Scenario__Group__0 ) ) ;
    public final void ruleScenario() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:166:2: ( ( ( rule__Scenario__Group__0 ) ) )
            // InternalMydsl.g:167:2: ( ( rule__Scenario__Group__0 ) )
            {
            // InternalMydsl.g:167:2: ( ( rule__Scenario__Group__0 ) )
            // InternalMydsl.g:168:3: ( rule__Scenario__Group__0 )
            {
             before(grammarAccess.getScenarioAccess().getGroup()); 
            // InternalMydsl.g:169:3: ( rule__Scenario__Group__0 )
            // InternalMydsl.g:169:4: rule__Scenario__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Scenario__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getScenarioAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleScenario"


    // $ANTLR start "entryRuleRule"
    // InternalMydsl.g:178:1: entryRuleRule : ruleRule EOF ;
    public final void entryRuleRule() throws RecognitionException {
        try {
            // InternalMydsl.g:179:1: ( ruleRule EOF )
            // InternalMydsl.g:180:1: ruleRule EOF
            {
             before(grammarAccess.getRuleRule()); 
            pushFollow(FOLLOW_1);
            ruleRule();

            state._fsp--;

             after(grammarAccess.getRuleRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRule"


    // $ANTLR start "ruleRule"
    // InternalMydsl.g:187:1: ruleRule : ( ( rule__Rule__Alternatives ) ) ;
    public final void ruleRule() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:191:2: ( ( ( rule__Rule__Alternatives ) ) )
            // InternalMydsl.g:192:2: ( ( rule__Rule__Alternatives ) )
            {
            // InternalMydsl.g:192:2: ( ( rule__Rule__Alternatives ) )
            // InternalMydsl.g:193:3: ( rule__Rule__Alternatives )
            {
             before(grammarAccess.getRuleAccess().getAlternatives()); 
            // InternalMydsl.g:194:3: ( rule__Rule__Alternatives )
            // InternalMydsl.g:194:4: rule__Rule__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Rule__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getRuleAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRule"


    // $ANTLR start "entryRuleGiven"
    // InternalMydsl.g:203:1: entryRuleGiven : ruleGiven EOF ;
    public final void entryRuleGiven() throws RecognitionException {
        try {
            // InternalMydsl.g:204:1: ( ruleGiven EOF )
            // InternalMydsl.g:205:1: ruleGiven EOF
            {
             before(grammarAccess.getGivenRule()); 
            pushFollow(FOLLOW_1);
            ruleGiven();

            state._fsp--;

             after(grammarAccess.getGivenRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleGiven"


    // $ANTLR start "ruleGiven"
    // InternalMydsl.g:212:1: ruleGiven : ( ( rule__Given__Group__0 ) ) ;
    public final void ruleGiven() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:216:2: ( ( ( rule__Given__Group__0 ) ) )
            // InternalMydsl.g:217:2: ( ( rule__Given__Group__0 ) )
            {
            // InternalMydsl.g:217:2: ( ( rule__Given__Group__0 ) )
            // InternalMydsl.g:218:3: ( rule__Given__Group__0 )
            {
             before(grammarAccess.getGivenAccess().getGroup()); 
            // InternalMydsl.g:219:3: ( rule__Given__Group__0 )
            // InternalMydsl.g:219:4: rule__Given__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Given__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getGivenAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGiven"


    // $ANTLR start "entryRuleAnd"
    // InternalMydsl.g:228:1: entryRuleAnd : ruleAnd EOF ;
    public final void entryRuleAnd() throws RecognitionException {
        try {
            // InternalMydsl.g:229:1: ( ruleAnd EOF )
            // InternalMydsl.g:230:1: ruleAnd EOF
            {
             before(grammarAccess.getAndRule()); 
            pushFollow(FOLLOW_1);
            ruleAnd();

            state._fsp--;

             after(grammarAccess.getAndRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAnd"


    // $ANTLR start "ruleAnd"
    // InternalMydsl.g:237:1: ruleAnd : ( ( rule__And__Group__0 ) ) ;
    public final void ruleAnd() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:241:2: ( ( ( rule__And__Group__0 ) ) )
            // InternalMydsl.g:242:2: ( ( rule__And__Group__0 ) )
            {
            // InternalMydsl.g:242:2: ( ( rule__And__Group__0 ) )
            // InternalMydsl.g:243:3: ( rule__And__Group__0 )
            {
             before(grammarAccess.getAndAccess().getGroup()); 
            // InternalMydsl.g:244:3: ( rule__And__Group__0 )
            // InternalMydsl.g:244:4: rule__And__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__And__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getAndAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAnd"


    // $ANTLR start "entryRuleTex"
    // InternalMydsl.g:253:1: entryRuleTex : ruleTex EOF ;
    public final void entryRuleTex() throws RecognitionException {
        try {
            // InternalMydsl.g:254:1: ( ruleTex EOF )
            // InternalMydsl.g:255:1: ruleTex EOF
            {
             before(grammarAccess.getTexRule()); 
            pushFollow(FOLLOW_1);
            ruleTex();

            state._fsp--;

             after(grammarAccess.getTexRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTex"


    // $ANTLR start "ruleTex"
    // InternalMydsl.g:262:1: ruleTex : ( RULE_INT ) ;
    public final void ruleTex() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:266:2: ( ( RULE_INT ) )
            // InternalMydsl.g:267:2: ( RULE_INT )
            {
            // InternalMydsl.g:267:2: ( RULE_INT )
            // InternalMydsl.g:268:3: RULE_INT
            {
             before(grammarAccess.getTexAccess().getINTTerminalRuleCall()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getTexAccess().getINTTerminalRuleCall()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTex"


    // $ANTLR start "rule__Element__Alternatives"
    // InternalMydsl.g:277:1: rule__Element__Alternatives : ( ( ruleIhave ) | ( ruleIdr ) );
    public final void rule__Element__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:281:1: ( ( ruleIhave ) | ( ruleIdr ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_I_HAVE) ) {
                alt1=1;
            }
            else if ( (LA1_0==RULE_DRANK) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalMydsl.g:282:2: ( ruleIhave )
                    {
                    // InternalMydsl.g:282:2: ( ruleIhave )
                    // InternalMydsl.g:283:3: ruleIhave
                    {
                     before(grammarAccess.getElementAccess().getIhaveParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleIhave();

                    state._fsp--;

                     after(grammarAccess.getElementAccess().getIhaveParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMydsl.g:288:2: ( ruleIdr )
                    {
                    // InternalMydsl.g:288:2: ( ruleIdr )
                    // InternalMydsl.g:289:3: ruleIdr
                    {
                     before(grammarAccess.getElementAccess().getIdrParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleIdr();

                    state._fsp--;

                     after(grammarAccess.getElementAccess().getIdrParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Alternatives"


    // $ANTLR start "rule__Rule__Alternatives"
    // InternalMydsl.g:298:1: rule__Rule__Alternatives : ( ( ruleGiven ) | ( ruleAnd ) );
    public final void rule__Rule__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:302:1: ( ( ruleGiven ) | ( ruleAnd ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==RULE_GIVEN_TEXT) ) {
                alt2=1;
            }
            else if ( (LA2_0==RULE_AND_TEXT) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalMydsl.g:303:2: ( ruleGiven )
                    {
                    // InternalMydsl.g:303:2: ( ruleGiven )
                    // InternalMydsl.g:304:3: ruleGiven
                    {
                     before(grammarAccess.getRuleAccess().getGivenParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleGiven();

                    state._fsp--;

                     after(grammarAccess.getRuleAccess().getGivenParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMydsl.g:309:2: ( ruleAnd )
                    {
                    // InternalMydsl.g:309:2: ( ruleAnd )
                    // InternalMydsl.g:310:3: ruleAnd
                    {
                     before(grammarAccess.getRuleAccess().getAndParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleAnd();

                    state._fsp--;

                     after(grammarAccess.getRuleAccess().getAndParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__Alternatives"


    // $ANTLR start "rule__Model__Group__0"
    // InternalMydsl.g:319:1: rule__Model__Group__0 : rule__Model__Group__0__Impl rule__Model__Group__1 ;
    public final void rule__Model__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:323:1: ( rule__Model__Group__0__Impl rule__Model__Group__1 )
            // InternalMydsl.g:324:2: rule__Model__Group__0__Impl rule__Model__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Model__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0"


    // $ANTLR start "rule__Model__Group__0__Impl"
    // InternalMydsl.g:331:1: rule__Model__Group__0__Impl : ( ( rule__Model__ElementsAssignment_0 )* ) ;
    public final void rule__Model__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:335:1: ( ( ( rule__Model__ElementsAssignment_0 )* ) )
            // InternalMydsl.g:336:1: ( ( rule__Model__ElementsAssignment_0 )* )
            {
            // InternalMydsl.g:336:1: ( ( rule__Model__ElementsAssignment_0 )* )
            // InternalMydsl.g:337:2: ( rule__Model__ElementsAssignment_0 )*
            {
             before(grammarAccess.getModelAccess().getElementsAssignment_0()); 
            // InternalMydsl.g:338:2: ( rule__Model__ElementsAssignment_0 )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( ((LA3_0>=RULE_I_HAVE && LA3_0<=RULE_DRANK)) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalMydsl.g:338:3: rule__Model__ElementsAssignment_0
            	    {
            	    pushFollow(FOLLOW_4);
            	    rule__Model__ElementsAssignment_0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getElementsAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0__Impl"


    // $ANTLR start "rule__Model__Group__1"
    // InternalMydsl.g:346:1: rule__Model__Group__1 : rule__Model__Group__1__Impl ;
    public final void rule__Model__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:350:1: ( rule__Model__Group__1__Impl )
            // InternalMydsl.g:351:2: rule__Model__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Model__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1"


    // $ANTLR start "rule__Model__Group__1__Impl"
    // InternalMydsl.g:357:1: rule__Model__Group__1__Impl : ( ( rule__Model__ScenariosAssignment_1 )* ) ;
    public final void rule__Model__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:361:1: ( ( ( rule__Model__ScenariosAssignment_1 )* ) )
            // InternalMydsl.g:362:1: ( ( rule__Model__ScenariosAssignment_1 )* )
            {
            // InternalMydsl.g:362:1: ( ( rule__Model__ScenariosAssignment_1 )* )
            // InternalMydsl.g:363:2: ( rule__Model__ScenariosAssignment_1 )*
            {
             before(grammarAccess.getModelAccess().getScenariosAssignment_1()); 
            // InternalMydsl.g:364:2: ( rule__Model__ScenariosAssignment_1 )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==RULE_DRINKING) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalMydsl.g:364:3: rule__Model__ScenariosAssignment_1
            	    {
            	    pushFollow(FOLLOW_5);
            	    rule__Model__ScenariosAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getScenariosAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1__Impl"


    // $ANTLR start "rule__Scenario__Group__0"
    // InternalMydsl.g:373:1: rule__Scenario__Group__0 : rule__Scenario__Group__0__Impl rule__Scenario__Group__1 ;
    public final void rule__Scenario__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:377:1: ( rule__Scenario__Group__0__Impl rule__Scenario__Group__1 )
            // InternalMydsl.g:378:2: rule__Scenario__Group__0__Impl rule__Scenario__Group__1
            {
            pushFollow(FOLLOW_6);
            rule__Scenario__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Scenario__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Scenario__Group__0"


    // $ANTLR start "rule__Scenario__Group__0__Impl"
    // InternalMydsl.g:385:1: rule__Scenario__Group__0__Impl : ( ( rule__Scenario__NameAssignment_0 ) ) ;
    public final void rule__Scenario__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:389:1: ( ( ( rule__Scenario__NameAssignment_0 ) ) )
            // InternalMydsl.g:390:1: ( ( rule__Scenario__NameAssignment_0 ) )
            {
            // InternalMydsl.g:390:1: ( ( rule__Scenario__NameAssignment_0 ) )
            // InternalMydsl.g:391:2: ( rule__Scenario__NameAssignment_0 )
            {
             before(grammarAccess.getScenarioAccess().getNameAssignment_0()); 
            // InternalMydsl.g:392:2: ( rule__Scenario__NameAssignment_0 )
            // InternalMydsl.g:392:3: rule__Scenario__NameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Scenario__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getScenarioAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Scenario__Group__0__Impl"


    // $ANTLR start "rule__Scenario__Group__1"
    // InternalMydsl.g:400:1: rule__Scenario__Group__1 : rule__Scenario__Group__1__Impl rule__Scenario__Group__2 ;
    public final void rule__Scenario__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:404:1: ( rule__Scenario__Group__1__Impl rule__Scenario__Group__2 )
            // InternalMydsl.g:405:2: rule__Scenario__Group__1__Impl rule__Scenario__Group__2
            {
            pushFollow(FOLLOW_6);
            rule__Scenario__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Scenario__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Scenario__Group__1"


    // $ANTLR start "rule__Scenario__Group__1__Impl"
    // InternalMydsl.g:412:1: rule__Scenario__Group__1__Impl : ( ( rule__Scenario__ElementsAssignment_1 )* ) ;
    public final void rule__Scenario__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:416:1: ( ( ( rule__Scenario__ElementsAssignment_1 )* ) )
            // InternalMydsl.g:417:1: ( ( rule__Scenario__ElementsAssignment_1 )* )
            {
            // InternalMydsl.g:417:1: ( ( rule__Scenario__ElementsAssignment_1 )* )
            // InternalMydsl.g:418:2: ( rule__Scenario__ElementsAssignment_1 )*
            {
             before(grammarAccess.getScenarioAccess().getElementsAssignment_1()); 
            // InternalMydsl.g:419:2: ( rule__Scenario__ElementsAssignment_1 )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( ((LA5_0>=RULE_I_HAVE && LA5_0<=RULE_DRANK)) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalMydsl.g:419:3: rule__Scenario__ElementsAssignment_1
            	    {
            	    pushFollow(FOLLOW_4);
            	    rule__Scenario__ElementsAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

             after(grammarAccess.getScenarioAccess().getElementsAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Scenario__Group__1__Impl"


    // $ANTLR start "rule__Scenario__Group__2"
    // InternalMydsl.g:427:1: rule__Scenario__Group__2 : rule__Scenario__Group__2__Impl ;
    public final void rule__Scenario__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:431:1: ( rule__Scenario__Group__2__Impl )
            // InternalMydsl.g:432:2: rule__Scenario__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Scenario__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Scenario__Group__2"


    // $ANTLR start "rule__Scenario__Group__2__Impl"
    // InternalMydsl.g:438:1: rule__Scenario__Group__2__Impl : ( ( rule__Scenario__RulesAssignment_2 )* ) ;
    public final void rule__Scenario__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:442:1: ( ( ( rule__Scenario__RulesAssignment_2 )* ) )
            // InternalMydsl.g:443:1: ( ( rule__Scenario__RulesAssignment_2 )* )
            {
            // InternalMydsl.g:443:1: ( ( rule__Scenario__RulesAssignment_2 )* )
            // InternalMydsl.g:444:2: ( rule__Scenario__RulesAssignment_2 )*
            {
             before(grammarAccess.getScenarioAccess().getRulesAssignment_2()); 
            // InternalMydsl.g:445:2: ( rule__Scenario__RulesAssignment_2 )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( ((LA6_0>=RULE_GIVEN_TEXT && LA6_0<=RULE_AND_TEXT)) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalMydsl.g:445:3: rule__Scenario__RulesAssignment_2
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__Scenario__RulesAssignment_2();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

             after(grammarAccess.getScenarioAccess().getRulesAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Scenario__Group__2__Impl"


    // $ANTLR start "rule__Given__Group__0"
    // InternalMydsl.g:454:1: rule__Given__Group__0 : rule__Given__Group__0__Impl rule__Given__Group__1 ;
    public final void rule__Given__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:458:1: ( rule__Given__Group__0__Impl rule__Given__Group__1 )
            // InternalMydsl.g:459:2: rule__Given__Group__0__Impl rule__Given__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Given__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Given__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Given__Group__0"


    // $ANTLR start "rule__Given__Group__0__Impl"
    // InternalMydsl.g:466:1: rule__Given__Group__0__Impl : ( ( rule__Given__DescAssignment_0 ) ) ;
    public final void rule__Given__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:470:1: ( ( ( rule__Given__DescAssignment_0 ) ) )
            // InternalMydsl.g:471:1: ( ( rule__Given__DescAssignment_0 ) )
            {
            // InternalMydsl.g:471:1: ( ( rule__Given__DescAssignment_0 ) )
            // InternalMydsl.g:472:2: ( rule__Given__DescAssignment_0 )
            {
             before(grammarAccess.getGivenAccess().getDescAssignment_0()); 
            // InternalMydsl.g:473:2: ( rule__Given__DescAssignment_0 )
            // InternalMydsl.g:473:3: rule__Given__DescAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Given__DescAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getGivenAccess().getDescAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Given__Group__0__Impl"


    // $ANTLR start "rule__Given__Group__1"
    // InternalMydsl.g:481:1: rule__Given__Group__1 : rule__Given__Group__1__Impl ;
    public final void rule__Given__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:485:1: ( rule__Given__Group__1__Impl )
            // InternalMydsl.g:486:2: rule__Given__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Given__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Given__Group__1"


    // $ANTLR start "rule__Given__Group__1__Impl"
    // InternalMydsl.g:492:1: rule__Given__Group__1__Impl : ( ( rule__Given__DescAssignment_1 )* ) ;
    public final void rule__Given__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:496:1: ( ( ( rule__Given__DescAssignment_1 )* ) )
            // InternalMydsl.g:497:1: ( ( rule__Given__DescAssignment_1 )* )
            {
            // InternalMydsl.g:497:1: ( ( rule__Given__DescAssignment_1 )* )
            // InternalMydsl.g:498:2: ( rule__Given__DescAssignment_1 )*
            {
             before(grammarAccess.getGivenAccess().getDescAssignment_1()); 
            // InternalMydsl.g:499:2: ( rule__Given__DescAssignment_1 )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==RULE_INT) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalMydsl.g:499:3: rule__Given__DescAssignment_1
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Given__DescAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

             after(grammarAccess.getGivenAccess().getDescAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Given__Group__1__Impl"


    // $ANTLR start "rule__And__Group__0"
    // InternalMydsl.g:508:1: rule__And__Group__0 : rule__And__Group__0__Impl rule__And__Group__1 ;
    public final void rule__And__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:512:1: ( rule__And__Group__0__Impl rule__And__Group__1 )
            // InternalMydsl.g:513:2: rule__And__Group__0__Impl rule__And__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__And__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__And__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__And__Group__0"


    // $ANTLR start "rule__And__Group__0__Impl"
    // InternalMydsl.g:520:1: rule__And__Group__0__Impl : ( ( rule__And__DescAssignment_0 ) ) ;
    public final void rule__And__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:524:1: ( ( ( rule__And__DescAssignment_0 ) ) )
            // InternalMydsl.g:525:1: ( ( rule__And__DescAssignment_0 ) )
            {
            // InternalMydsl.g:525:1: ( ( rule__And__DescAssignment_0 ) )
            // InternalMydsl.g:526:2: ( rule__And__DescAssignment_0 )
            {
             before(grammarAccess.getAndAccess().getDescAssignment_0()); 
            // InternalMydsl.g:527:2: ( rule__And__DescAssignment_0 )
            // InternalMydsl.g:527:3: rule__And__DescAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__And__DescAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getAndAccess().getDescAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__And__Group__0__Impl"


    // $ANTLR start "rule__And__Group__1"
    // InternalMydsl.g:535:1: rule__And__Group__1 : rule__And__Group__1__Impl ;
    public final void rule__And__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:539:1: ( rule__And__Group__1__Impl )
            // InternalMydsl.g:540:2: rule__And__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__And__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__And__Group__1"


    // $ANTLR start "rule__And__Group__1__Impl"
    // InternalMydsl.g:546:1: rule__And__Group__1__Impl : ( ( rule__And__DescAssignment_1 )* ) ;
    public final void rule__And__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:550:1: ( ( ( rule__And__DescAssignment_1 )* ) )
            // InternalMydsl.g:551:1: ( ( rule__And__DescAssignment_1 )* )
            {
            // InternalMydsl.g:551:1: ( ( rule__And__DescAssignment_1 )* )
            // InternalMydsl.g:552:2: ( rule__And__DescAssignment_1 )*
            {
             before(grammarAccess.getAndAccess().getDescAssignment_1()); 
            // InternalMydsl.g:553:2: ( rule__And__DescAssignment_1 )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==RULE_INT) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalMydsl.g:553:3: rule__And__DescAssignment_1
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__And__DescAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

             after(grammarAccess.getAndAccess().getDescAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__And__Group__1__Impl"


    // $ANTLR start "rule__Model__ElementsAssignment_0"
    // InternalMydsl.g:562:1: rule__Model__ElementsAssignment_0 : ( ruleElement ) ;
    public final void rule__Model__ElementsAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:566:1: ( ( ruleElement ) )
            // InternalMydsl.g:567:2: ( ruleElement )
            {
            // InternalMydsl.g:567:2: ( ruleElement )
            // InternalMydsl.g:568:3: ruleElement
            {
             before(grammarAccess.getModelAccess().getElementsElementParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleElement();

            state._fsp--;

             after(grammarAccess.getModelAccess().getElementsElementParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__ElementsAssignment_0"


    // $ANTLR start "rule__Model__ScenariosAssignment_1"
    // InternalMydsl.g:577:1: rule__Model__ScenariosAssignment_1 : ( ruleScenario ) ;
    public final void rule__Model__ScenariosAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:581:1: ( ( ruleScenario ) )
            // InternalMydsl.g:582:2: ( ruleScenario )
            {
            // InternalMydsl.g:582:2: ( ruleScenario )
            // InternalMydsl.g:583:3: ruleScenario
            {
             before(grammarAccess.getModelAccess().getScenariosScenarioParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleScenario();

            state._fsp--;

             after(grammarAccess.getModelAccess().getScenariosScenarioParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__ScenariosAssignment_1"


    // $ANTLR start "rule__Ihave__NameAssignment"
    // InternalMydsl.g:592:1: rule__Ihave__NameAssignment : ( RULE_I_HAVE ) ;
    public final void rule__Ihave__NameAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:596:1: ( ( RULE_I_HAVE ) )
            // InternalMydsl.g:597:2: ( RULE_I_HAVE )
            {
            // InternalMydsl.g:597:2: ( RULE_I_HAVE )
            // InternalMydsl.g:598:3: RULE_I_HAVE
            {
             before(grammarAccess.getIhaveAccess().getNameI_HAVETerminalRuleCall_0()); 
            match(input,RULE_I_HAVE,FOLLOW_2); 
             after(grammarAccess.getIhaveAccess().getNameI_HAVETerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ihave__NameAssignment"


    // $ANTLR start "rule__Idr__NameAssignment"
    // InternalMydsl.g:607:1: rule__Idr__NameAssignment : ( RULE_DRANK ) ;
    public final void rule__Idr__NameAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:611:1: ( ( RULE_DRANK ) )
            // InternalMydsl.g:612:2: ( RULE_DRANK )
            {
            // InternalMydsl.g:612:2: ( RULE_DRANK )
            // InternalMydsl.g:613:3: RULE_DRANK
            {
             before(grammarAccess.getIdrAccess().getNameDRANKTerminalRuleCall_0()); 
            match(input,RULE_DRANK,FOLLOW_2); 
             after(grammarAccess.getIdrAccess().getNameDRANKTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Idr__NameAssignment"


    // $ANTLR start "rule__Scenario__NameAssignment_0"
    // InternalMydsl.g:622:1: rule__Scenario__NameAssignment_0 : ( RULE_DRINKING ) ;
    public final void rule__Scenario__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:626:1: ( ( RULE_DRINKING ) )
            // InternalMydsl.g:627:2: ( RULE_DRINKING )
            {
            // InternalMydsl.g:627:2: ( RULE_DRINKING )
            // InternalMydsl.g:628:3: RULE_DRINKING
            {
             before(grammarAccess.getScenarioAccess().getNameDRINKINGTerminalRuleCall_0_0()); 
            match(input,RULE_DRINKING,FOLLOW_2); 
             after(grammarAccess.getScenarioAccess().getNameDRINKINGTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Scenario__NameAssignment_0"


    // $ANTLR start "rule__Scenario__ElementsAssignment_1"
    // InternalMydsl.g:637:1: rule__Scenario__ElementsAssignment_1 : ( ruleElement ) ;
    public final void rule__Scenario__ElementsAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:641:1: ( ( ruleElement ) )
            // InternalMydsl.g:642:2: ( ruleElement )
            {
            // InternalMydsl.g:642:2: ( ruleElement )
            // InternalMydsl.g:643:3: ruleElement
            {
             before(grammarAccess.getScenarioAccess().getElementsElementParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleElement();

            state._fsp--;

             after(grammarAccess.getScenarioAccess().getElementsElementParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Scenario__ElementsAssignment_1"


    // $ANTLR start "rule__Scenario__RulesAssignment_2"
    // InternalMydsl.g:652:1: rule__Scenario__RulesAssignment_2 : ( ruleRule ) ;
    public final void rule__Scenario__RulesAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:656:1: ( ( ruleRule ) )
            // InternalMydsl.g:657:2: ( ruleRule )
            {
            // InternalMydsl.g:657:2: ( ruleRule )
            // InternalMydsl.g:658:3: ruleRule
            {
             before(grammarAccess.getScenarioAccess().getRulesRuleParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleRule();

            state._fsp--;

             after(grammarAccess.getScenarioAccess().getRulesRuleParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Scenario__RulesAssignment_2"


    // $ANTLR start "rule__Given__DescAssignment_0"
    // InternalMydsl.g:667:1: rule__Given__DescAssignment_0 : ( RULE_GIVEN_TEXT ) ;
    public final void rule__Given__DescAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:671:1: ( ( RULE_GIVEN_TEXT ) )
            // InternalMydsl.g:672:2: ( RULE_GIVEN_TEXT )
            {
            // InternalMydsl.g:672:2: ( RULE_GIVEN_TEXT )
            // InternalMydsl.g:673:3: RULE_GIVEN_TEXT
            {
             before(grammarAccess.getGivenAccess().getDescGIVEN_TEXTTerminalRuleCall_0_0()); 
            match(input,RULE_GIVEN_TEXT,FOLLOW_2); 
             after(grammarAccess.getGivenAccess().getDescGIVEN_TEXTTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Given__DescAssignment_0"


    // $ANTLR start "rule__Given__DescAssignment_1"
    // InternalMydsl.g:682:1: rule__Given__DescAssignment_1 : ( ruleTex ) ;
    public final void rule__Given__DescAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:686:1: ( ( ruleTex ) )
            // InternalMydsl.g:687:2: ( ruleTex )
            {
            // InternalMydsl.g:687:2: ( ruleTex )
            // InternalMydsl.g:688:3: ruleTex
            {
             before(grammarAccess.getGivenAccess().getDescTexParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleTex();

            state._fsp--;

             after(grammarAccess.getGivenAccess().getDescTexParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Given__DescAssignment_1"


    // $ANTLR start "rule__And__DescAssignment_0"
    // InternalMydsl.g:697:1: rule__And__DescAssignment_0 : ( RULE_AND_TEXT ) ;
    public final void rule__And__DescAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:701:1: ( ( RULE_AND_TEXT ) )
            // InternalMydsl.g:702:2: ( RULE_AND_TEXT )
            {
            // InternalMydsl.g:702:2: ( RULE_AND_TEXT )
            // InternalMydsl.g:703:3: RULE_AND_TEXT
            {
             before(grammarAccess.getAndAccess().getDescAND_TEXTTerminalRuleCall_0_0()); 
            match(input,RULE_AND_TEXT,FOLLOW_2); 
             after(grammarAccess.getAndAccess().getDescAND_TEXTTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__And__DescAssignment_0"


    // $ANTLR start "rule__And__DescAssignment_1"
    // InternalMydsl.g:712:1: rule__And__DescAssignment_1 : ( ruleTex ) ;
    public final void rule__And__DescAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMydsl.g:716:1: ( ( ruleTex ) )
            // InternalMydsl.g:717:2: ( ruleTex )
            {
            // InternalMydsl.g:717:2: ( ruleTex )
            // InternalMydsl.g:718:3: ruleTex
            {
             before(grammarAccess.getAndAccess().getDescTexParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleTex();

            state._fsp--;

             after(grammarAccess.getAndAccess().getDescTexParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__And__DescAssignment_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000062L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000360L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000302L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000012L});

}