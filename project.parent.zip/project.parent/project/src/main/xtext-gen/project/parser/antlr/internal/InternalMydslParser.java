package project.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import project.services.MydslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMydslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_I_HAVE", "RULE_DRANK", "RULE_DRINKING", "RULE_GIVEN_TEXT", "RULE_AND_TEXT", "RULE_INT", "RULE_COKES", "RULE_ID", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER"
    };
    public static final int RULE_ID=11;
    public static final int RULE_I_HAVE=4;
    public static final int RULE_WS=15;
    public static final int RULE_DRANK=5;
    public static final int RULE_STRING=12;
    public static final int RULE_ANY_OTHER=16;
    public static final int RULE_SL_COMMENT=14;
    public static final int RULE_GIVEN_TEXT=7;
    public static final int RULE_DRINKING=6;
    public static final int RULE_INT=9;
    public static final int RULE_ML_COMMENT=13;
    public static final int EOF=-1;
    public static final int RULE_COKES=10;
    public static final int RULE_AND_TEXT=8;

    // delegates
    // delegators


        public InternalMydslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMydslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMydslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMydsl.g"; }



     	private MydslGrammarAccess grammarAccess;

        public InternalMydslParser(TokenStream input, MydslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "model";
       	}

       	@Override
       	protected MydslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRulemodel"
    // InternalMydsl.g:64:1: entryRulemodel returns [EObject current=null] : iv_rulemodel= rulemodel EOF ;
    public final EObject entryRulemodel() throws RecognitionException {
        EObject current = null;

        EObject iv_rulemodel = null;


        try {
            // InternalMydsl.g:64:46: (iv_rulemodel= rulemodel EOF )
            // InternalMydsl.g:65:2: iv_rulemodel= rulemodel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_rulemodel=rulemodel();

            state._fsp--;

             current =iv_rulemodel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulemodel"


    // $ANTLR start "rulemodel"
    // InternalMydsl.g:71:1: rulemodel returns [EObject current=null] : ( ( (lv_elements_0_0= ruleElement ) )* ( (lv_scenarios_1_0= ruleScenario ) )* ) ;
    public final EObject rulemodel() throws RecognitionException {
        EObject current = null;

        EObject lv_elements_0_0 = null;

        EObject lv_scenarios_1_0 = null;



        	enterRule();

        try {
            // InternalMydsl.g:77:2: ( ( ( (lv_elements_0_0= ruleElement ) )* ( (lv_scenarios_1_0= ruleScenario ) )* ) )
            // InternalMydsl.g:78:2: ( ( (lv_elements_0_0= ruleElement ) )* ( (lv_scenarios_1_0= ruleScenario ) )* )
            {
            // InternalMydsl.g:78:2: ( ( (lv_elements_0_0= ruleElement ) )* ( (lv_scenarios_1_0= ruleScenario ) )* )
            // InternalMydsl.g:79:3: ( (lv_elements_0_0= ruleElement ) )* ( (lv_scenarios_1_0= ruleScenario ) )*
            {
            // InternalMydsl.g:79:3: ( (lv_elements_0_0= ruleElement ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=RULE_I_HAVE && LA1_0<=RULE_DRANK)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalMydsl.g:80:4: (lv_elements_0_0= ruleElement )
            	    {
            	    // InternalMydsl.g:80:4: (lv_elements_0_0= ruleElement )
            	    // InternalMydsl.g:81:5: lv_elements_0_0= ruleElement
            	    {

            	    					newCompositeNode(grammarAccess.getModelAccess().getElementsElementParserRuleCall_0_0());
            	    				
            	    pushFollow(FOLLOW_3);
            	    lv_elements_0_0=ruleElement();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"elements",
            	    						lv_elements_0_0,
            	    						"project.Mydsl.Element");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            // InternalMydsl.g:98:3: ( (lv_scenarios_1_0= ruleScenario ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==RULE_DRINKING) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalMydsl.g:99:4: (lv_scenarios_1_0= ruleScenario )
            	    {
            	    // InternalMydsl.g:99:4: (lv_scenarios_1_0= ruleScenario )
            	    // InternalMydsl.g:100:5: lv_scenarios_1_0= ruleScenario
            	    {

            	    					newCompositeNode(grammarAccess.getModelAccess().getScenariosScenarioParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_4);
            	    lv_scenarios_1_0=ruleScenario();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"scenarios",
            	    						lv_scenarios_1_0,
            	    						"project.Mydsl.Scenario");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulemodel"


    // $ANTLR start "entryRuleElement"
    // InternalMydsl.g:121:1: entryRuleElement returns [EObject current=null] : iv_ruleElement= ruleElement EOF ;
    public final EObject entryRuleElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElement = null;


        try {
            // InternalMydsl.g:121:48: (iv_ruleElement= ruleElement EOF )
            // InternalMydsl.g:122:2: iv_ruleElement= ruleElement EOF
            {
             newCompositeNode(grammarAccess.getElementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleElement=ruleElement();

            state._fsp--;

             current =iv_ruleElement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElement"


    // $ANTLR start "ruleElement"
    // InternalMydsl.g:128:1: ruleElement returns [EObject current=null] : (this_Ihave_0= ruleIhave | this_Idr_1= ruleIdr ) ;
    public final EObject ruleElement() throws RecognitionException {
        EObject current = null;

        EObject this_Ihave_0 = null;

        EObject this_Idr_1 = null;



        	enterRule();

        try {
            // InternalMydsl.g:134:2: ( (this_Ihave_0= ruleIhave | this_Idr_1= ruleIdr ) )
            // InternalMydsl.g:135:2: (this_Ihave_0= ruleIhave | this_Idr_1= ruleIdr )
            {
            // InternalMydsl.g:135:2: (this_Ihave_0= ruleIhave | this_Idr_1= ruleIdr )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==RULE_I_HAVE) ) {
                alt3=1;
            }
            else if ( (LA3_0==RULE_DRANK) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalMydsl.g:136:3: this_Ihave_0= ruleIhave
                    {

                    			newCompositeNode(grammarAccess.getElementAccess().getIhaveParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Ihave_0=ruleIhave();

                    state._fsp--;


                    			current = this_Ihave_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMydsl.g:145:3: this_Idr_1= ruleIdr
                    {

                    			newCompositeNode(grammarAccess.getElementAccess().getIdrParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Idr_1=ruleIdr();

                    state._fsp--;


                    			current = this_Idr_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElement"


    // $ANTLR start "entryRuleIhave"
    // InternalMydsl.g:157:1: entryRuleIhave returns [EObject current=null] : iv_ruleIhave= ruleIhave EOF ;
    public final EObject entryRuleIhave() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIhave = null;


        try {
            // InternalMydsl.g:157:46: (iv_ruleIhave= ruleIhave EOF )
            // InternalMydsl.g:158:2: iv_ruleIhave= ruleIhave EOF
            {
             newCompositeNode(grammarAccess.getIhaveRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIhave=ruleIhave();

            state._fsp--;

             current =iv_ruleIhave; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIhave"


    // $ANTLR start "ruleIhave"
    // InternalMydsl.g:164:1: ruleIhave returns [EObject current=null] : ( (lv_name_0_0= RULE_I_HAVE ) ) ;
    public final EObject ruleIhave() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;


        	enterRule();

        try {
            // InternalMydsl.g:170:2: ( ( (lv_name_0_0= RULE_I_HAVE ) ) )
            // InternalMydsl.g:171:2: ( (lv_name_0_0= RULE_I_HAVE ) )
            {
            // InternalMydsl.g:171:2: ( (lv_name_0_0= RULE_I_HAVE ) )
            // InternalMydsl.g:172:3: (lv_name_0_0= RULE_I_HAVE )
            {
            // InternalMydsl.g:172:3: (lv_name_0_0= RULE_I_HAVE )
            // InternalMydsl.g:173:4: lv_name_0_0= RULE_I_HAVE
            {
            lv_name_0_0=(Token)match(input,RULE_I_HAVE,FOLLOW_2); 

            				newLeafNode(lv_name_0_0, grammarAccess.getIhaveAccess().getNameI_HAVETerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getIhaveRule());
            				}
            				setWithLastConsumed(
            					current,
            					"name",
            					lv_name_0_0,
            					"project.Mydsl.I_HAVE");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIhave"


    // $ANTLR start "entryRuleIdr"
    // InternalMydsl.g:192:1: entryRuleIdr returns [EObject current=null] : iv_ruleIdr= ruleIdr EOF ;
    public final EObject entryRuleIdr() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIdr = null;


        try {
            // InternalMydsl.g:192:44: (iv_ruleIdr= ruleIdr EOF )
            // InternalMydsl.g:193:2: iv_ruleIdr= ruleIdr EOF
            {
             newCompositeNode(grammarAccess.getIdrRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIdr=ruleIdr();

            state._fsp--;

             current =iv_ruleIdr; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIdr"


    // $ANTLR start "ruleIdr"
    // InternalMydsl.g:199:1: ruleIdr returns [EObject current=null] : ( (lv_name_0_0= RULE_DRANK ) ) ;
    public final EObject ruleIdr() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;


        	enterRule();

        try {
            // InternalMydsl.g:205:2: ( ( (lv_name_0_0= RULE_DRANK ) ) )
            // InternalMydsl.g:206:2: ( (lv_name_0_0= RULE_DRANK ) )
            {
            // InternalMydsl.g:206:2: ( (lv_name_0_0= RULE_DRANK ) )
            // InternalMydsl.g:207:3: (lv_name_0_0= RULE_DRANK )
            {
            // InternalMydsl.g:207:3: (lv_name_0_0= RULE_DRANK )
            // InternalMydsl.g:208:4: lv_name_0_0= RULE_DRANK
            {
            lv_name_0_0=(Token)match(input,RULE_DRANK,FOLLOW_2); 

            				newLeafNode(lv_name_0_0, grammarAccess.getIdrAccess().getNameDRANKTerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getIdrRule());
            				}
            				setWithLastConsumed(
            					current,
            					"name",
            					lv_name_0_0,
            					"project.Mydsl.DRANK");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIdr"


    // $ANTLR start "entryRuleScenario"
    // InternalMydsl.g:227:1: entryRuleScenario returns [EObject current=null] : iv_ruleScenario= ruleScenario EOF ;
    public final EObject entryRuleScenario() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleScenario = null;


        try {
            // InternalMydsl.g:227:49: (iv_ruleScenario= ruleScenario EOF )
            // InternalMydsl.g:228:2: iv_ruleScenario= ruleScenario EOF
            {
             newCompositeNode(grammarAccess.getScenarioRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleScenario=ruleScenario();

            state._fsp--;

             current =iv_ruleScenario; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleScenario"


    // $ANTLR start "ruleScenario"
    // InternalMydsl.g:234:1: ruleScenario returns [EObject current=null] : ( ( (lv_name_0_0= RULE_DRINKING ) ) ( (lv_elements_1_0= ruleElement ) )* ( (lv_rules_2_0= ruleRule ) )* ) ;
    public final EObject ruleScenario() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        EObject lv_elements_1_0 = null;

        EObject lv_rules_2_0 = null;



        	enterRule();

        try {
            // InternalMydsl.g:240:2: ( ( ( (lv_name_0_0= RULE_DRINKING ) ) ( (lv_elements_1_0= ruleElement ) )* ( (lv_rules_2_0= ruleRule ) )* ) )
            // InternalMydsl.g:241:2: ( ( (lv_name_0_0= RULE_DRINKING ) ) ( (lv_elements_1_0= ruleElement ) )* ( (lv_rules_2_0= ruleRule ) )* )
            {
            // InternalMydsl.g:241:2: ( ( (lv_name_0_0= RULE_DRINKING ) ) ( (lv_elements_1_0= ruleElement ) )* ( (lv_rules_2_0= ruleRule ) )* )
            // InternalMydsl.g:242:3: ( (lv_name_0_0= RULE_DRINKING ) ) ( (lv_elements_1_0= ruleElement ) )* ( (lv_rules_2_0= ruleRule ) )*
            {
            // InternalMydsl.g:242:3: ( (lv_name_0_0= RULE_DRINKING ) )
            // InternalMydsl.g:243:4: (lv_name_0_0= RULE_DRINKING )
            {
            // InternalMydsl.g:243:4: (lv_name_0_0= RULE_DRINKING )
            // InternalMydsl.g:244:5: lv_name_0_0= RULE_DRINKING
            {
            lv_name_0_0=(Token)match(input,RULE_DRINKING,FOLLOW_5); 

            					newLeafNode(lv_name_0_0, grammarAccess.getScenarioAccess().getNameDRINKINGTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getScenarioRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_0_0,
            						"project.Mydsl.DRINKING");
            				

            }


            }

            // InternalMydsl.g:260:3: ( (lv_elements_1_0= ruleElement ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( ((LA4_0>=RULE_I_HAVE && LA4_0<=RULE_DRANK)) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalMydsl.g:261:4: (lv_elements_1_0= ruleElement )
            	    {
            	    // InternalMydsl.g:261:4: (lv_elements_1_0= ruleElement )
            	    // InternalMydsl.g:262:5: lv_elements_1_0= ruleElement
            	    {

            	    					newCompositeNode(grammarAccess.getScenarioAccess().getElementsElementParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_6);
            	    lv_elements_1_0=ruleElement();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getScenarioRule());
            	    					}
            	    					add(
            	    						current,
            	    						"elements",
            	    						lv_elements_1_0,
            	    						"project.Mydsl.Element");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            // InternalMydsl.g:279:3: ( (lv_rules_2_0= ruleRule ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( ((LA5_0>=RULE_GIVEN_TEXT && LA5_0<=RULE_AND_TEXT)) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalMydsl.g:280:4: (lv_rules_2_0= ruleRule )
            	    {
            	    // InternalMydsl.g:280:4: (lv_rules_2_0= ruleRule )
            	    // InternalMydsl.g:281:5: lv_rules_2_0= ruleRule
            	    {

            	    					newCompositeNode(grammarAccess.getScenarioAccess().getRulesRuleParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_7);
            	    lv_rules_2_0=ruleRule();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getScenarioRule());
            	    					}
            	    					add(
            	    						current,
            	    						"rules",
            	    						lv_rules_2_0,
            	    						"project.Mydsl.Rule");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleScenario"


    // $ANTLR start "entryRuleRule"
    // InternalMydsl.g:302:1: entryRuleRule returns [EObject current=null] : iv_ruleRule= ruleRule EOF ;
    public final EObject entryRuleRule() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRule = null;


        try {
            // InternalMydsl.g:302:45: (iv_ruleRule= ruleRule EOF )
            // InternalMydsl.g:303:2: iv_ruleRule= ruleRule EOF
            {
             newCompositeNode(grammarAccess.getRuleRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRule=ruleRule();

            state._fsp--;

             current =iv_ruleRule; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRule"


    // $ANTLR start "ruleRule"
    // InternalMydsl.g:309:1: ruleRule returns [EObject current=null] : (this_Given_0= ruleGiven | this_And_1= ruleAnd ) ;
    public final EObject ruleRule() throws RecognitionException {
        EObject current = null;

        EObject this_Given_0 = null;

        EObject this_And_1 = null;



        	enterRule();

        try {
            // InternalMydsl.g:315:2: ( (this_Given_0= ruleGiven | this_And_1= ruleAnd ) )
            // InternalMydsl.g:316:2: (this_Given_0= ruleGiven | this_And_1= ruleAnd )
            {
            // InternalMydsl.g:316:2: (this_Given_0= ruleGiven | this_And_1= ruleAnd )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==RULE_GIVEN_TEXT) ) {
                alt6=1;
            }
            else if ( (LA6_0==RULE_AND_TEXT) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalMydsl.g:317:3: this_Given_0= ruleGiven
                    {

                    			newCompositeNode(grammarAccess.getRuleAccess().getGivenParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Given_0=ruleGiven();

                    state._fsp--;


                    			current = this_Given_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMydsl.g:326:3: this_And_1= ruleAnd
                    {

                    			newCompositeNode(grammarAccess.getRuleAccess().getAndParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_And_1=ruleAnd();

                    state._fsp--;


                    			current = this_And_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRule"


    // $ANTLR start "entryRuleGiven"
    // InternalMydsl.g:338:1: entryRuleGiven returns [EObject current=null] : iv_ruleGiven= ruleGiven EOF ;
    public final EObject entryRuleGiven() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGiven = null;


        try {
            // InternalMydsl.g:338:46: (iv_ruleGiven= ruleGiven EOF )
            // InternalMydsl.g:339:2: iv_ruleGiven= ruleGiven EOF
            {
             newCompositeNode(grammarAccess.getGivenRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGiven=ruleGiven();

            state._fsp--;

             current =iv_ruleGiven; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGiven"


    // $ANTLR start "ruleGiven"
    // InternalMydsl.g:345:1: ruleGiven returns [EObject current=null] : ( ( (lv_desc_0_0= RULE_GIVEN_TEXT ) ) ( (lv_desc_1_0= ruleTex ) )* ) ;
    public final EObject ruleGiven() throws RecognitionException {
        EObject current = null;

        Token lv_desc_0_0=null;
        AntlrDatatypeRuleToken lv_desc_1_0 = null;



        	enterRule();

        try {
            // InternalMydsl.g:351:2: ( ( ( (lv_desc_0_0= RULE_GIVEN_TEXT ) ) ( (lv_desc_1_0= ruleTex ) )* ) )
            // InternalMydsl.g:352:2: ( ( (lv_desc_0_0= RULE_GIVEN_TEXT ) ) ( (lv_desc_1_0= ruleTex ) )* )
            {
            // InternalMydsl.g:352:2: ( ( (lv_desc_0_0= RULE_GIVEN_TEXT ) ) ( (lv_desc_1_0= ruleTex ) )* )
            // InternalMydsl.g:353:3: ( (lv_desc_0_0= RULE_GIVEN_TEXT ) ) ( (lv_desc_1_0= ruleTex ) )*
            {
            // InternalMydsl.g:353:3: ( (lv_desc_0_0= RULE_GIVEN_TEXT ) )
            // InternalMydsl.g:354:4: (lv_desc_0_0= RULE_GIVEN_TEXT )
            {
            // InternalMydsl.g:354:4: (lv_desc_0_0= RULE_GIVEN_TEXT )
            // InternalMydsl.g:355:5: lv_desc_0_0= RULE_GIVEN_TEXT
            {
            lv_desc_0_0=(Token)match(input,RULE_GIVEN_TEXT,FOLLOW_8); 

            					newLeafNode(lv_desc_0_0, grammarAccess.getGivenAccess().getDescGIVEN_TEXTTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getGivenRule());
            					}
            					addWithLastConsumed(
            						current,
            						"desc",
            						lv_desc_0_0,
            						"project.Mydsl.GIVEN_TEXT");
            				

            }


            }

            // InternalMydsl.g:371:3: ( (lv_desc_1_0= ruleTex ) )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==RULE_INT) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalMydsl.g:372:4: (lv_desc_1_0= ruleTex )
            	    {
            	    // InternalMydsl.g:372:4: (lv_desc_1_0= ruleTex )
            	    // InternalMydsl.g:373:5: lv_desc_1_0= ruleTex
            	    {

            	    					newCompositeNode(grammarAccess.getGivenAccess().getDescTexParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_8);
            	    lv_desc_1_0=ruleTex();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getGivenRule());
            	    					}
            	    					add(
            	    						current,
            	    						"desc",
            	    						lv_desc_1_0,
            	    						"project.Mydsl.Tex");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGiven"


    // $ANTLR start "entryRuleAnd"
    // InternalMydsl.g:394:1: entryRuleAnd returns [EObject current=null] : iv_ruleAnd= ruleAnd EOF ;
    public final EObject entryRuleAnd() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAnd = null;


        try {
            // InternalMydsl.g:394:44: (iv_ruleAnd= ruleAnd EOF )
            // InternalMydsl.g:395:2: iv_ruleAnd= ruleAnd EOF
            {
             newCompositeNode(grammarAccess.getAndRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAnd=ruleAnd();

            state._fsp--;

             current =iv_ruleAnd; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAnd"


    // $ANTLR start "ruleAnd"
    // InternalMydsl.g:401:1: ruleAnd returns [EObject current=null] : ( ( (lv_desc_0_0= RULE_AND_TEXT ) ) ( (lv_desc_1_0= ruleTex ) )* ) ;
    public final EObject ruleAnd() throws RecognitionException {
        EObject current = null;

        Token lv_desc_0_0=null;
        AntlrDatatypeRuleToken lv_desc_1_0 = null;



        	enterRule();

        try {
            // InternalMydsl.g:407:2: ( ( ( (lv_desc_0_0= RULE_AND_TEXT ) ) ( (lv_desc_1_0= ruleTex ) )* ) )
            // InternalMydsl.g:408:2: ( ( (lv_desc_0_0= RULE_AND_TEXT ) ) ( (lv_desc_1_0= ruleTex ) )* )
            {
            // InternalMydsl.g:408:2: ( ( (lv_desc_0_0= RULE_AND_TEXT ) ) ( (lv_desc_1_0= ruleTex ) )* )
            // InternalMydsl.g:409:3: ( (lv_desc_0_0= RULE_AND_TEXT ) ) ( (lv_desc_1_0= ruleTex ) )*
            {
            // InternalMydsl.g:409:3: ( (lv_desc_0_0= RULE_AND_TEXT ) )
            // InternalMydsl.g:410:4: (lv_desc_0_0= RULE_AND_TEXT )
            {
            // InternalMydsl.g:410:4: (lv_desc_0_0= RULE_AND_TEXT )
            // InternalMydsl.g:411:5: lv_desc_0_0= RULE_AND_TEXT
            {
            lv_desc_0_0=(Token)match(input,RULE_AND_TEXT,FOLLOW_8); 

            					newLeafNode(lv_desc_0_0, grammarAccess.getAndAccess().getDescAND_TEXTTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAndRule());
            					}
            					addWithLastConsumed(
            						current,
            						"desc",
            						lv_desc_0_0,
            						"project.Mydsl.AND_TEXT");
            				

            }


            }

            // InternalMydsl.g:427:3: ( (lv_desc_1_0= ruleTex ) )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==RULE_INT) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalMydsl.g:428:4: (lv_desc_1_0= ruleTex )
            	    {
            	    // InternalMydsl.g:428:4: (lv_desc_1_0= ruleTex )
            	    // InternalMydsl.g:429:5: lv_desc_1_0= ruleTex
            	    {

            	    					newCompositeNode(grammarAccess.getAndAccess().getDescTexParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_8);
            	    lv_desc_1_0=ruleTex();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getAndRule());
            	    					}
            	    					add(
            	    						current,
            	    						"desc",
            	    						lv_desc_1_0,
            	    						"project.Mydsl.Tex");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAnd"


    // $ANTLR start "entryRuleTex"
    // InternalMydsl.g:450:1: entryRuleTex returns [String current=null] : iv_ruleTex= ruleTex EOF ;
    public final String entryRuleTex() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTex = null;


        try {
            // InternalMydsl.g:450:43: (iv_ruleTex= ruleTex EOF )
            // InternalMydsl.g:451:2: iv_ruleTex= ruleTex EOF
            {
             newCompositeNode(grammarAccess.getTexRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTex=ruleTex();

            state._fsp--;

             current =iv_ruleTex.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTex"


    // $ANTLR start "ruleTex"
    // InternalMydsl.g:457:1: ruleTex returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : this_INT_0= RULE_INT ;
    public final AntlrDatatypeRuleToken ruleTex() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_INT_0=null;


        	enterRule();

        try {
            // InternalMydsl.g:463:2: (this_INT_0= RULE_INT )
            // InternalMydsl.g:464:2: this_INT_0= RULE_INT
            {
            this_INT_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            		current.merge(this_INT_0);
            	

            		newLeafNode(this_INT_0, grammarAccess.getTexAccess().getINTTerminalRuleCall());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTex"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000072L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000042L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x00000000000001F0L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x00000000000001F2L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000182L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000202L});

}