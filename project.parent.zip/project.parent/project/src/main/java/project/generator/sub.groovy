package project.generator

import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.resource.XtextResourceSet

import com.google.inject.Injector

import project.MydslStandaloneSetup
import project.mydsl.util.*

class prroject {
	def static void main(String[] args) {
		// do this only once per application
		Injector injector = new MydslStandaloneSetup().createInjectorAndDoEMFRegistration();
		
		// obtain a resourceset from the injector
		XtextResourceSet resourceSet = injector.getInstance(XtextResourceSet.class);
		
		// load a resource by URI, in this case from the file system
		Resource resource = resourceSet.getResource(URI.createFileURI("src/main/resources/input.gherkin"), true);
		
		model m = resource.getContents().get(0)
		
		String text = process(m.elements)
		
		println(text)
}
def static String process(List<> list) {
	String text = ''
	for (el in list) {
		text += process(el)
	}
	return text
}
def static String process1(Element obj) {
	String text  = ''
	 """
	 private ${obj.type.name} ${obj.name};
	
	public ${obj.type.name} get${obj.name}() {
		return ${obj.name};
	}
	
	public void set${obj.name()}(${obj.type.name} ${obj.name}) {
		this.${obj.name} = ${obj.name};
	}
"""
}
    text
}